package TEST21212;

import java.net.*;
import java.io.*;

public class C03ServerBackground {
	//멤버변수
	private ServerSocket server;
	private Socket client;
	private DataInputStream in;
	private DataOutputStream out;
	private Sgui gui;
			
	//생성자 호출	
	public C03ServerBackground(Sgui gui){
		this.gui=gui;
	}
	
	public void Setup() {	
		try {
			server = new ServerSocket(2225);
			client = server.accept();
			gui.appendMSG(client.getInetAddress()+"님이 접속했습니다.");
			in = new DataInputStream(client.getInputStream());
			out = new DataOutputStream(client.getOutputStream());
			//무한루프(수신)
			while(in!=null)
			{
				String tmp=in.readUTF();
				gui.appendMSG(tmp);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	
	//메시지 전달 
	public void SendMessage(String msg) {
		try {
			out.writeUTF(msg);
			out.flush();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	

}

package TEST21212;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class C03ClientBackground {
		//멤버변수
		private Socket client;
		private DataInputStream in;
		private DataOutputStream out;
		private Cgui gui;
				
		//생성자 호출
		public C03ClientBackground(Cgui gui){
			this.gui=gui;
			System.out.println("생성자 호출완료!");
		}	
		public void Setup() {		
			try {
				client=new Socket("192.168.3.17", 5051);
				System.out.println("연결완료!");
				//in/out 스트림 객체 연결
				in = new DataInputStream(client.getInputStream());
				out = new DataOutputStream(client.getOutputStream());
				System.out.println("out : " + out);
				//무한루프(수신)
				while(in!=null)
				{
					String tmp=in.readUTF();
					gui.appendMSG(tmp);
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			
		}
		
		//메시지 전달 
		public void SendMessage(String msg) {
			try {
				out.writeUTF(msg);
				out.flush();
			}catch(Exception e) {
				e.printStackTrace();
			}
			
		}
		
	
	
}
